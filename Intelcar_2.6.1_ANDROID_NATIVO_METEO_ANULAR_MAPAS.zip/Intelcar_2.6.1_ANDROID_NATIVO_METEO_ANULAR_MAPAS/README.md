# Intelcar 2.6.1 — OSM + Meteorologia + Anular Viagem fecha Mapas

Base: Intelcar 2.6.

Novidades:
- Alertas meteorológicos reais via Open-Meteo, sem chave API e sem pagamento.
- Chuva forte, gelo/neve, nevoeiro, vento forte, trovoada e temperatura extrema.
- Comando "vai chover" / "meteorologia" responde por voz.
- Verificação automática da meteorologia a cada 10 minutos com GPS ativo.
- "Anular viagem" agora termina a viagem, limpa o destino, remove o marcador e fecha o mapa interno.
- Comando "fechar mapas" fecha apenas o mapa interno e mantém o Intelcar ativo.
- Botão do mapa agora reabre/centra o mapa interno.

Mantém:
- Microfone corrigido.
- Sem anúncio automático da velocidade.
- Apito forte sem vibração.
- Câmara de fadiga/distração.
- Condução perigosa.
- Google Maps externo como plano B.
