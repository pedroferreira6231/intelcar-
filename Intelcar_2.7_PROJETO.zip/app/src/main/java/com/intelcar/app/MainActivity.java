package com.intelcar.app;

import android.Manifest;
import androidx.activity.ComponentActivity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PointF;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.location.Geocoder;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.UtteranceProgressListener;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.media.AudioManager;
import android.media.ToneGenerator;
import androidx.annotation.NonNull;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ExperimentalGetImage;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceContour;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.text.Normalizer;
import java.util.*;
import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;

public class MainActivity extends ComponentActivity implements RecognitionListener, SensorEventListener, LocationListener {
    TextView title, status, speed, destinationLine, weatherStatus, sensor, mode, aiState, fatigueStatus, log;
    Button micBtn, mapsBtn, internalMapBtn, terminateTripBtn, testBtn, levelBtn, privacyBtn, helpBtn, cameraBtn, beepBtn;
    PreviewView cameraPreview;
    MapView osmMap;
    Marker carMarker, destinationMarker;

    SpeechRecognizer recognizer;
    TextToSpeech tts;
    SensorManager sensorManager;
    LocationManager locationManager;
    FaceDetector faceDetector;
    ExecutorService cameraExecutor;
    ProcessCameraProvider cameraProvider;
    ToneGenerator emergencyTone;

    boolean micWanted = false;
    boolean recognitionActive = false;
    boolean recognitionStarting = false;
    boolean privacy = true;
    boolean aiCopilot = true;
    boolean intelcarSpeaking = false;
    boolean waitingForCommand = false;
    boolean tripStarted = false;
    boolean fatigueCameraActive = false;
    boolean processingFaceFrame = false;
    boolean internalMapEnabled = true;

    Handler handler = new Handler(Looper.getMainLooper());
    Runnable restartRunnable = null;

    int level = 1;
    float lastMotion = 0f;
    double currentSpeed = 0;
    double lastLat = 0;
    double lastLon = 0;

    long lastAggressive = 0;
    long lastRestart = 0;
    long lastFatigueWarning = 0;
    long tripStartTime = 0;
    long waitingUntil = 0;
    long eyesClosedSince = 0;
    long gazeAwaySince = 0;
    long yawnOpenSince = 0;
    long lastEyeCriticalAlert = 0;
    long lastDistractionAlert = 0;
    long lastYawnAlert = 0;
    long lastBeep = 0;
    long lastWeatherCheck = 0;
    long lastWeatherAlert = 0;
    int yawnCount = 0;

    String weatherSummary = "Meteorologia: ainda sem leitura";

    String destination = "Fátima";
    String lastHeard = "";

    String[] levels = {"Suave", "Normal", "Forte", "Muito forte"};
    float[] thresholds = {3.5f, 5.0f, 7.0f, 9.0f};

    public void onCreate(Bundle b) {
        super.onCreate(b);
        Configuration.getInstance().setUserAgentValue(getPackageName());
        buildUi();

        requestPermissions(new String[]{
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.CAMERA
        }, 12);

        tts = new TextToSpeech(this, s -> {
            if (s == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("pt", "PT"));
                tts.setSpeechRate(1.0f);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    public void onStart(String utteranceId) {
                        intelcarSpeaking = true;
                    }

                    public void onDone(String utteranceId) {
                        intelcarSpeaking = false;
                        handler.postDelayed(() -> { if (micWanted) scheduleRestart(250); }, 250);
                    }

                    public void onError(String utteranceId) {
                        intelcarSpeaking = false;
                        handler.postDelayed(() -> { if (micWanted) scheduleRestart(250); }, 250);
                    }
                });
                speak("Intelcar dois ponto sete. Modo carro horizontal preparado.");
            }
        });

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        cameraExecutor = Executors.newSingleThreadExecutor();
        emergencyTone = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
        FaceDetectorOptions faceOptions = new FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
                .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                .enableTracking()
                .build();
        faceDetector = FaceDetection.getClient(faceOptions);

        startSensors();
        startGps();
        setupRecognizer();
        updateAiState();
    }

    void buildUi() {
        boolean landscape = getResources().getConfiguration().orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(landscape ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        root.setPadding(landscape ? 14 : 26, landscape ? 10 : 26, landscape ? 14 : 26, landscape ? 10 : 26);
        root.setBackgroundColor(Color.rgb(7, 16, 24));
        setContentView(root);

        title = tv("INTELCAR 2.7", landscape ? 20 : 28, true);
        status = tv("Android nativo • modo carro horizontal • OSM grátis", landscape ? 13 : 16, false);
        speed = tv("0 km/h", landscape ? 64 : 54, true);
        destinationLine = tv("📍 Destino: " + destination, landscape ? 24 : 22, true);
        sensor = tv("Sensor: 0.0", landscape ? 14 : 18, false);
        mode = tv("Modo: Privacidade Máxima", landscape ? 14 : 18, false);
        aiState = tv("IA: pronta", landscape ? 14 : 17, false);
        fatigueStatus = tv("Fadiga/Distração: câmara desligada", landscape ? 14 : 17, false);
        weatherStatus = tv("🌦️ Meteorologia: a aguardar GPS", landscape ? 14 : 17, false);
        cameraPreview = new PreviewView(this);
        cameraPreview.setVisibility(fatigueCameraActive ? View.VISIBLE : View.GONE);
        cameraPreview.setMinimumHeight(landscape ? 180 : 260);

        osmMap = new MapView(this);
        osmMap.setTileSource(TileSourceFactory.MAPNIK);
        osmMap.setMultiTouchControls(true);
        osmMap.getController().setZoom(15.0);
        osmMap.setMinimumHeight(landscape ? 360 : 420);
        osmMap.setVisibility(internalMapEnabled ? View.VISIBLE : View.GONE);

        log = tv("Diga: 'Olá Intelcar', 'leva-me a Fátima', 'estou com sono', 'ajuda'", landscape ? 12 : 15, false);

        micBtn = btn("🎤 Ligar microfone IA");
        mapsBtn = btn("🗺️ Abrir Google Maps externo");
        internalMapBtn = btn(internalMapEnabled ? "🗺️ Centrar mapa Intelcar" : "🗺️ Abrir mapa Intelcar");
        terminateTripBtn = btn("⛔ Anular viagem");
        testBtn = btn("⚠️ Testar condução agressiva");
        levelBtn = btn("Nível condução: " + levels[level]);
        privacyBtn = btn(privacy ? "🔒 Privacidade Máxima" : "🤖 IA Completa");
        helpBtn = btn("🤖 Ajuda do Copiloto IA");
        cameraBtn = btn(fatigueCameraActive ? "👁️ Câmara fadiga ligada" : "👁️ Ligar câmara fadiga");
        beepBtn = btn("🔊 Testar apito forte");

        if (landscape) {
            buildLandscapeUi(root);
        } else {
            buildPortraitUi(root);
        }

        micBtn.setOnClickListener(v -> { if (micWanted || recognitionActive || recognitionStarting) stopListening(); else startListening(); });
        mapsBtn.setOnClickListener(v -> openMaps(destination));
        internalMapBtn.setOnClickListener(v -> { if (osmMap.getVisibility() == View.GONE) openInternalMap(); else centerInternalMap(); });
        terminateTripBtn.setOnClickListener(v -> terminateIntelcarTrip(true));
        testBtn.setOnClickListener(v -> aggressiveAlert());
        levelBtn.setOnClickListener(v -> { level = (level + 1) % levels.length; levelBtn.setText("Nível condução: " + levels[level]); });
        privacyBtn.setOnClickListener(v -> { privacy = !privacy; privacyBtn.setText(privacy ? "🔒 Privacidade Máxima" : "🤖 IA Completa"); mode.setText("Modo: " + (privacy ? "Privacidade Máxima" : "IA Completa")); updateAiState(); });
        helpBtn.setOnClickListener(v -> speakHelp());
        cameraBtn.setOnClickListener(v -> { if (fatigueCameraActive) stopFatigueCamera(); else startFatigueCamera(); });
        beepBtn.setOnClickListener(v -> criticalBeep());

        updateAiState();
        updateMicButton();
        if (weatherSummary != null && weatherStatus != null) weatherStatus.setText("🌦️ " + weatherSummary);
        if (lastLat != 0 && lastLon != 0) {
            speed.setText(Math.round(currentSpeed) + " km/h");
            centerInternalMap();
        }
    }

    void buildPortraitUi(LinearLayout root) {
        root.addView(title);
        root.addView(status);
        root.addView(card(speed));
        root.addView(card(destinationLine));
        root.addView(osmMap);
        root.addView(card(sensor));
        root.addView(card(mode));
        root.addView(card(aiState));
        root.addView(card(weatherStatus));
        root.addView(card(fatigueStatus));
        root.addView(cameraPreview);
        root.addView(micBtn);
        root.addView(mapsBtn);
        root.addView(internalMapBtn);
        root.addView(terminateTripBtn);
        root.addView(testBtn);
        root.addView(levelBtn);
        root.addView(privacyBtn);
        root.addView(helpBtn);
        root.addView(cameraBtn);
        root.addView(beepBtn);
        root.addView(log);
    }

    void buildLandscapeUi(LinearLayout root) {
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setPadding(8, 4, 8, 4);
        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setPadding(8, 4, 8, 4);
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setPadding(8, 4, 8, 4);

        root.addView(left, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1.15f));
        root.addView(center, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 2.3f));

        ScrollView rightScroll = new ScrollView(this);
        rightScroll.addView(right);
        root.addView(rightScroll, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1.35f));

        left.addView(title);
        left.addView(card(speed));
        left.addView(card(destinationLine));
        left.addView(card(aiState));
        left.addView(micBtn);
        left.addView(terminateTripBtn);
        left.addView(beepBtn);

        center.addView(osmMap, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        center.addView(cameraPreview, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, fatigueCameraActive ? 180 : 0));
        center.addView(log);

        right.addView(status);
        right.addView(card(weatherStatus));
        right.addView(card(fatigueStatus));
        right.addView(card(sensor));
        right.addView(card(mode));
        right.addView(internalMapBtn);
        right.addView(mapsBtn);
        right.addView(cameraBtn);
        right.addView(testBtn);
        right.addView(levelBtn);
        right.addView(privacyBtn);
        right.addView(helpBtn);
    }

    TextView tv(String s, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextColor(Color.WHITE);
        v.setTextSize(sp);
        v.setGravity(Gravity.CENTER);
        if (bold) v.setTypeface(null, 1);
        v.setPadding(8, 12, 8, 12);
        return v;
    }

    TextView card(TextView v) {
        v.setBackgroundColor(Color.rgb(15, 33, 48));
        return v;
    }

    Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(17);
        return b;
    }

    void updateAiState() {
        aiState.setText("IA: copiloto local ativo • destino: " + destination);
        if (destinationLine != null) destinationLine.setText(destination == null || destination.length() == 0 ? "📍 Destino: sem destino" : "📍 Destino: " + destination);
    }

    void setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("Reconhecimento de voz indisponível neste Android");
            return;
        }

        destroyRecognizerOnly();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(this);
    }

    Intent recognizerIntent() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-PT");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        return i;
    }

    void startListening() {
        micWanted = true;

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status.setText("Toque em Permitir para ativar o microfone");
            requestPermissions(new String[]{ Manifest.permission.RECORD_AUDIO }, 21);
            updateMicButton();
            return;
        }

        if (intelcarSpeaking) {
            scheduleRestart(700);
            updateMicButton();
            return;
        }

        if (recognitionActive || recognitionStarting) {
            updateMicButton();
            return;
        }

        setupRecognizer();
        if (recognizer == null) {
            updateMicButton();
            return;
        }

        recognitionStarting = true;
        updateMicButton();

        try {
            recognizer.startListening(recognizerIntent());
        } catch (Exception e) {
            recognitionStarting = false;
            recognitionActive = false;
            destroyRecognizerOnly();
            scheduleRestart(900);
            updateMicButton();
        }
    }

    void stopListening() {
        micWanted = false;
        recognitionActive = false;
        recognitionStarting = false;
        waitingForCommand = false;

        if (restartRunnable != null) {
            handler.removeCallbacks(restartRunnable);
            restartRunnable = null;
        }

        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) {}
        }

        status.setText("Microfone desligado");
        updateMicButton();
    }

    void destroyRecognizerOnly() {
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) {}
            try { recognizer.destroy(); } catch (Exception ignored) {}
            recognizer = null;
        }
    }

    void scheduleRestart(long delay) {
        if (!micWanted) return;

        if (restartRunnable != null) {
            handler.removeCallbacks(restartRunnable);
        }

        restartRunnable = () -> {
            restartRunnable = null;
            if (micWanted && !intelcarSpeaking) {
                recognitionActive = false;
                recognitionStarting = false;
                startListening();
            }
        };

        handler.postDelayed(restartRunnable, delay);
    }

    void updateMicButton() {
        if (micBtn == null) return;

        if (recognitionActive) {
            micBtn.setText("🔴 Microfone IA ligado");
            status.setText("A ouvir. Diga: Olá Intelcar.");
        } else if (recognitionStarting) {
            micBtn.setText("🟠 A ligar microfone...");
            status.setText("A ligar microfone...");
        } else if (micWanted) {
            micBtn.setText("🟡 Microfone em espera");
            status.setText("Microfone em espera. A religar automaticamente.");
        } else {
            micBtn.setText("🎤 Ligar microfone IA");
        }
    }

    public void onResults(Bundle r) {
        if (intelcarSpeaking) {
            scheduleRestart(900);
            return;
        }

        ArrayList<String> a = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (a != null && !a.isEmpty()) {
            String best = a.get(0);
            for (String option : a) {
                String n = normalize(option);
                if (n.contains("intelcar") || n.startsWith("ola") || looksLikeCommand(n)) {
                    best = option;
                    break;
                }
            }
            handle(best);
        }

        recognitionActive = false;
        recognitionStarting = false;
        destroyRecognizerOnly();
        updateMicButton();
        scheduleRestart(350);
    }

    public void onPartialResults(Bundle r) {
        ArrayList<String> a = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (a != null && !a.isEmpty()) {
            lastHeard = a.get(0);
            log.setText("Ouvi: " + lastHeard);
        }
    }

    String normalize(String raw) {
        String n = Normalizer.normalize(raw.toLowerCase(Locale.ROOT), Normalizer.Form.NFD);
        n = n.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
        n = n.replaceAll("[^a-z0-9 ]", " ");
        return n.replaceAll("\\s+", " ").trim();
    }

    void handle(String raw) {
        String t = normalize(raw);
        log.setText("Comando: " + raw);

        boolean wake = t.equals("ola") || t.equals("ola intelcar") || t.equals("intelcar") || t.startsWith("ola ") || t.startsWith("intelcar ");
        if (wake) {
            t = t.replaceFirst("^ola intelcar ?", "").replaceFirst("^ola ?", "").replaceFirst("^intelcar ?", "").trim();
            if (t.length() == 0) {
                waitingForCommand = true;
                waitingUntil = System.currentTimeMillis() + 10000;
                speak("Estou aqui Pedro. Pode falar.");
                return;
            }
        }

        if (waitingForCommand && System.currentTimeMillis() <= waitingUntil) {
            waitingForCommand = false;
        } else if (!wake && aiCopilot) {
            // No Android nativo aceitamos comandos diretos, mas ignoramos conversa solta sem palavras úteis.
            if (!looksLikeCommand(t)) return;
        }

        if (t.contains("ajuda") || t.contains("o que sabes fazer") || t.contains("comandos")) {
            speakHelp();
            return;
        }

        if (t.contains("velocidade")) {
            speak("A velocidade está visível no ecrã do Intelcar.");
            return;
        }

        if (t.contains("iniciar viagem") || t.contains("comecar viagem") || t.contains("começar viagem")) {
            startTripIfNeeded();
            speak("Viagem iniciada. Vou acompanhar a condução.");
            return;
        }

        if (t.contains("estou com sono") || t.contains("tenho sono") || t.contains("cansado") || t.contains("cansada")) {
            fatigueAlert(true);
            return;
        }

        if (t.contains("ligar camara") || t.contains("ligar câmara") || t.contains("camara fadiga") || t.contains("câmara fadiga")) {
            startFatigueCamera();
            speak("Câmara de fadiga ligada. Vou vigiar olhos fechados, distração e bocejos.");
            return;
        }

        if (t.contains("desligar camara") || t.contains("desligar câmara")) {
            stopFatigueCamera();
            speak("Câmara de fadiga desligada.");
            return;
        }

        if (t.contains("testar apito") || t.contains("apito forte")) {
            criticalBeep();
            speak("Teste de apito forte.");
            return;
        }

        if (t.contains("estado da viagem") || t.contains("como vai a viagem") || t.contains("relatorio") || t.contains("relatório")) {
            speakTripReport();
            return;
        }

        if (t.contains("terminar viagem") || t.contains("anular viagem") || t.contains("cancelar viagem") || t.contains("parar viagem")) {
            terminateIntelcarTrip(true);
            return;
        }

        if (t.contains("fechar mapas") || t.contains("fechar mapa")) {
            closeInternalMap();
            speak("Mapas fechados. Painel principal ativo.");
            return;
        }

        if (t.contains("centrar mapa") || t.contains("abrir mapa") || t.contains("mapa intelcar") || t.contains("mapa interno")) {
            openInternalMap();
            speak("Mapa Intelcar aberto e centrado na posição atual.");
            return;
        }

        if (t.contains("modo privacidade")) {
            privacy = true;
            privacyBtn.setText("🔒 Privacidade Máxima");
            mode.setText("Modo: Privacidade Máxima");
            speak("Modo de privacidade máxima ativado.");
            return;
        }

        if (t.contains("ia completa") || t.contains("modo ia")) {
            privacy = false;
            privacyBtn.setText("🤖 IA Completa");
            mode.setText("Modo: IA Completa");
            speak("Modo IA completa ativado. Nesta versão a inteligência é local e segura.");
            return;
        }

        String newDestination = extractDestination(t);
        if (newDestination.length() > 0) {
            destination = beautifyDestination(newDestination);
            updateAiState();
            showDestinationOnInternalMap(destination);
            speak("Destino definido para " + destination + ". Mapa Intelcar atualizado. Se quiser, posso abrir o Google Maps externo.");
            return;
        }

        if (t.contains("maps") || t.contains("mapas") || t.contains("navegacao") || t.contains("navegação")) {
            speak("A abrir Google Maps externo para " + destination + ".");
            status.postDelayed(() -> openMaps(destination), 800);
            return;
        }

        if (t.contains("conducao agressiva") || t.contains("condução agressiva") || t.contains("movimento brusco") || t.contains("travagem brusca")) {
            aggressiveAlert();
            return;
        }

        if (t.contains("chuva") || t.contains("tempo") || t.contains("meteorologia") || t.contains("gelo") || t.contains("nevoeiro") || t.contains("vento")) {
            checkWeatherNow(true);
            return;
        }

        if (!privacy && (t.contains("explica") || t.contains("porque") || t.contains("por que") || t.contains("quem") || t.contains("qual"))) {
            speak("Consigo ser o copiloto e interpretar comandos de condução. Para conversa livre completa ainda falta ligar um serviço de inteligência artificial online.");
            return;
        }

        speak("Não compreendi bem. Diga ajuda para ouvir exemplos.");
    }

    boolean looksLikeCommand(String t) {
        String[] keys = {"velocidade", "maps", "mapas", "naveg", "sono", "cans", "chuva", "tempo", "meteorologia", "gelo", "nevoeiro", "vento", "ajuda", "destino", "leva", "conduc", "condu", "viagem", "privacidade", "ia", "camara", "camera", "câmara", "apito", "terminar", "anular", "cancelar", "fechar mapa", "fechar mapas", "mapa interno", "centrar mapa"};
        for (String k : keys) if (t.contains(k)) return true;
        return false;
    }

    String extractDestination(String t) {
        String[] patterns = {"leva me a ", "leva me para ", "ir para ", "quero ir para ", "destino ", "navegar para ", "abre maps para ", "abrir maps para ", "abre o maps para "};
        for (String p : patterns) {
            int idx = t.indexOf(p);
            if (idx >= 0) {
                String d = t.substring(idx + p.length()).trim();
                d = d.replace(" o destino", "").trim();
                if (d.length() >= 2) return d;
            }
        }
        return "";
    }

    String beautifyDestination(String d) {
        String[] parts = d.split(" ");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.length() == 0) continue;
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)).append(" ");
        }
        return sb.toString().trim();
    }

    void speakHelp() {
        speak("Pode dizer: Olá Intelcar. Leva-me a Fátima. Anular viagem. Fechar mapas. Centrar mapa. Estou com sono. Ligar câmara fadiga. Testar apito. Como vai a viagem. Vai chover. Pode virar o telemóvel para horizontal para o modo carro.");
    }

    void speakTripReport() {
        long mins = tripStarted ? Math.max(0, (System.currentTimeMillis() - tripStartTime) / 60000) : 0;
        String moving = currentSpeed > 5 ? "em movimento" : "parado ou muito devagar";
        speak("Estado da viagem. Veículo " + moving + ". Tempo de viagem " + mins + " minutos. Destino " + destination + ". Mapa Intelcar ativo. Sensibilidade " + levels[level] + ".");
    }

    void startTripIfNeeded() {
        if (!tripStarted) {
            tripStarted = true;
            tripStartTime = System.currentTimeMillis();
        }
    }

    void fatigueAlert(boolean userSaidIt) {
        long now = System.currentTimeMillis();
        if (!userSaidIt && now - lastFatigueWarning < 20 * 60 * 1000) return;
        lastFatigueWarning = now;
        speak("Pedro, recomendo fazer uma pausa assim que possível. Se estiver com sono, não arrisque. A segurança vem primeiro.");
    }

    void speak(String s) {
        if (tts == null) return;

        intelcarSpeaking = true;

        // Para o Android não ouvir a própria voz do Intelcar.
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) {}
        }
        recognitionActive = false;
        recognitionStarting = false;
        updateMicButton();

        tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "intelcar");

        // Segurança extra caso o TextToSpeech não chame onDone em alguns telemóveis.
        handler.postDelayed(() -> {
            intelcarSpeaking = false;
            if (micWanted) scheduleRestart(250);
        }, Math.max(1800, s.length() * 80));
    }

    void startFatigueCamera() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{ Manifest.permission.CAMERA }, 31);
            fatigueStatus.setText("Fadiga/Distração: falta permissão da câmara");
            return;
        }

        fatigueCameraActive = true;
        cameraBtn.setText("👁️ Câmara fadiga ligada");
        cameraPreview.setVisibility(View.VISIBLE);
        fatigueStatus.setText("Fadiga/Distração: a iniciar câmara frontal...");

        ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider.getInstance(this);
        cameraProviderFuture.addListener(() -> {
            try {
                cameraProvider = cameraProviderFuture.get();
                bindFatigueCamera();
            } catch (Exception e) {
                fatigueCameraActive = false;
                fatigueStatus.setText("Fadiga/Distração: erro ao iniciar câmara");
            }
        }, command -> handler.post(command));
    }

    @ExperimentalGetImage
    void bindFatigueCamera() {
        if (cameraProvider == null) return;

        Preview preview = new Preview.Builder().build();
        preview.setSurfaceProvider(cameraPreview.getSurfaceProvider());

        ImageAnalysis analysis = new ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build();

        analysis.setAnalyzer(cameraExecutor, imageProxy -> analyzeCameraFrame(imageProxy));

        CameraSelector selector = new CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_FRONT)
                .build();

        try {
            cameraProvider.unbindAll();
            cameraProvider.bindToLifecycle(this, selector, preview, analysis);
            fatigueStatus.setText("Fadiga/Distração: ativa • olhos, distração e bocejos");
        } catch (Exception e) {
            fatigueCameraActive = false;
            fatigueStatus.setText("Fadiga/Distração: não consegui ligar a câmara frontal");
        }
    }

    @ExperimentalGetImage
    void analyzeCameraFrame(ImageProxy imageProxy) {
        if (!fatigueCameraActive || processingFaceFrame || imageProxy.getImage() == null) {
            imageProxy.close();
            return;
        }

        processingFaceFrame = true;
        InputImage image = InputImage.fromMediaImage(imageProxy.getImage(), imageProxy.getImageInfo().getRotationDegrees());

        faceDetector.process(image)
                .addOnSuccessListener(faces -> {
                    if (faces == null || faces.isEmpty()) {
                        handler.post(() -> fatigueStatus.setText("Fadiga/Distração: rosto não detetado"));
                        eyesClosedSince = 0;
                        gazeAwaySince = 0;
                        return;
                    }
                    analyzeFace(faces.get(0));
                })
                .addOnFailureListener(e -> handler.post(() -> fatigueStatus.setText("Fadiga/Distração: erro na análise facial")))
                .addOnCompleteListener(task -> {
                    processingFaceFrame = false;
                    imageProxy.close();
                });
    }

    void analyzeFace(Face face) {
        long now = System.currentTimeMillis();

        Float left = face.getLeftEyeOpenProbability();
        Float right = face.getRightEyeOpenProbability();
        boolean eyesClosed = left != null && right != null && left < 0.35f && right < 0.35f;

        float yaw = Math.abs(face.getHeadEulerAngleY());
        float pitch = face.getHeadEulerAngleX();
        boolean distracted = yaw > 25f || pitch > 18f;

        boolean yawning = isYawning(face);

        if (eyesClosed) {
            if (eyesClosedSince == 0) eyesClosedSince = now;
            long closedMs = now - eyesClosedSince;
            handler.post(() -> fatigueStatus.setText("Fadiga: olhos fechados " + (closedMs / 1000.0) + " s"));
            if (closedMs >= 2000 && now - lastEyeCriticalAlert > 3500) {
                lastEyeCriticalAlert = now;
                criticalBeep();
                speak("Pedro, atenção. Olhos fechados. Acorde e reduza a velocidade.");
            }
        } else {
            eyesClosedSince = 0;
        }

        if (distracted) {
            if (gazeAwaySince == 0) gazeAwaySince = now;
            long awayMs = now - gazeAwaySince;
            if (awayMs >= 2000 && now - lastDistractionAlert > 5000) {
                lastDistractionAlert = now;
                criticalBeep();
                speak("Atenção. Está a olhar para fora da estrada há mais de dois segundos.");
            }
        } else {
            gazeAwaySince = 0;
        }

        if (yawning) {
            if (yawnOpenSince == 0) yawnOpenSince = now;
            if (now - yawnOpenSince > 900 && now - lastYawnAlert > 25000) {
                yawnCount += 1;
                lastYawnAlert = now;
                speak("Bocejo detetado. Recomendo uma pausa em breve.");
            }
        } else {
            yawnOpenSince = 0;
        }

        if (!eyesClosed && !distracted && !yawning) {
            handler.post(() -> fatigueStatus.setText("Fadiga/Distração: normal"));
        }
    }

    boolean isYawning(Face face) {
        try {
            FaceContour upper = face.getContour(FaceContour.UPPER_LIP_TOP);
            FaceContour lower = face.getContour(FaceContour.LOWER_LIP_BOTTOM);
            if (upper == null || lower == null || upper.getPoints().isEmpty() || lower.getPoints().isEmpty()) return false;
            float upperY = averageY(upper.getPoints());
            float lowerY = averageY(lower.getPoints());
            float mouthOpen = Math.abs(lowerY - upperY);
            float faceHeight = Math.max(1, face.getBoundingBox().height());
            return mouthOpen / faceHeight > 0.105f;
        } catch (Exception e) {
            return false;
        }
    }

    float averageY(List<PointF> points) {
        float total = 0f;
        for (PointF p : points) total += p.y;
        return total / Math.max(1, points.size());
    }

    void criticalBeep() {
        long now = System.currentTimeMillis();
        if (now - lastBeep < 900) return;
        lastBeep = now;
        try {
            emergencyTone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 900);
        } catch (Exception ignored) {}
    }

    void stopFatigueCamera() {
        fatigueCameraActive = false;
        if (cameraProvider != null) {
            try { cameraProvider.unbindAll(); } catch (Exception ignored) {}
        }
        eyesClosedSince = 0;
        gazeAwaySince = 0;
        yawnOpenSince = 0;
        cameraPreview.setVisibility(View.GONE);
        cameraBtn.setText("👁️ Ligar câmara fadiga");
        fatigueStatus.setText("Fadiga/Distração: câmara desligada");
    }


    void centerInternalMap() {
        if (osmMap == null) return;
        if (lastLat != 0 && lastLon != 0) {
            GeoPoint point = new GeoPoint(lastLat, lastLon);
            osmMap.getController().setZoom(16.0);
            osmMap.getController().animateTo(point);
            updateCarMarker(point);
        } else {
            GeoPoint portugal = new GeoPoint(39.5, -8.0);
            osmMap.getController().setZoom(7.0);
            osmMap.getController().setCenter(portugal);
        }
        osmMap.invalidate();
    }

    void updateCarMarker(GeoPoint point) {
        if (osmMap == null || point == null) return;
        if (carMarker == null) {
            carMarker = new Marker(osmMap);
            carMarker.setTitle("Intelcar — posição atual");
            carMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
            osmMap.getOverlays().add(carMarker);
        }
        carMarker.setPosition(point);
        osmMap.invalidate();
    }

    void showDestinationOnInternalMap(String dest) {
        if (osmMap == null || dest == null || dest.trim().length() == 0) return;
        updateAiState();
        try {
            Geocoder geocoder = new Geocoder(this, new Locale("pt", "PT"));
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                geocoder.getFromLocationName(dest + ", Portugal", 1, addresses -> {
                    if (addresses != null && !addresses.isEmpty()) {
                        LocationPointOnMap(addresses.get(0).getLatitude(), addresses.get(0).getLongitude(), dest);
                    }
                });
            } else {
                List<android.location.Address> addresses = geocoder.getFromLocationName(dest + ", Portugal", 1);
                if (addresses != null && !addresses.isEmpty()) {
                    LocationPointOnMap(addresses.get(0).getLatitude(), addresses.get(0).getLongitude(), dest);
                }
            }
        } catch (Exception e) {
            status.setText("Destino guardado. Mapa sem geocodificação neste momento.");
        }
    }

    void LocationPointOnMap(double lat, double lon, String titleText) {
        handler.post(() -> {
            GeoPoint p = new GeoPoint(lat, lon);
            if (destinationMarker == null) {
                destinationMarker = new Marker(osmMap);
                destinationMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
                osmMap.getOverlays().add(destinationMarker);
            }
            destinationMarker.setPosition(p);
            destinationMarker.setTitle("Destino: " + titleText);
            osmMap.getController().animateTo(p);
            osmMap.invalidate();
        });
    }

    void terminateIntelcarTrip(boolean speakNow) {
        tripStarted = false;
        tripStartTime = 0;
        destination = "";
        updateAiState();
        closeInternalMap();
        if (destinationMarker != null && osmMap != null) {
            try { osmMap.getOverlays().remove(destinationMarker); } catch (Exception ignored) {}
            destinationMarker = null;
            osmMap.invalidate();
        }
        if (speakNow) speak("Viagem anulada. Mapas fechados e painel principal ativo.");
    }

    void closeInternalMap() {
        internalMapEnabled = false;
        if (osmMap != null) osmMap.setVisibility(View.GONE);
        if (internalMapBtn != null) internalMapBtn.setText("🗺️ Abrir mapa Intelcar");
    }

    void openInternalMap() {
        internalMapEnabled = true;
        if (osmMap != null) osmMap.setVisibility(View.VISIBLE);
        if (internalMapBtn != null) internalMapBtn.setText("🗺️ Centrar mapa Intelcar");
        centerInternalMap();
    }


    void checkWeatherNow(boolean speakResult) {
        if (lastLat == 0 || lastLon == 0) {
            if (speakResult) speak("Ainda não tenho localização GPS para verificar a meteorologia.");
            return;
        }
        lastWeatherCheck = System.currentTimeMillis();
        if (weatherStatus != null) weatherStatus.setText("🌦️ Meteorologia: a verificar...");
        new Thread(() -> {
            try {
                String urlText = "https://api.open-meteo.com/v1/forecast?latitude=" + lastLat +
                        "&longitude=" + lastLon +
                        "&current=temperature_2m,precipitation,rain,showers,snowfall,weather_code,wind_speed_10m,wind_gusts_10m,visibility";
                java.net.URL url = new java.net.URL(urlText);
                java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(7000);
                conn.setReadTimeout(7000);
                conn.setRequestMethod("GET");
                java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);
                reader.close();
                String json = sb.toString();
                double temp = getJsonNumber(json, "temperature_2m", 99);
                double rain = Math.max(getJsonNumber(json, "rain", 0), getJsonNumber(json, "showers", 0));
                double precipitation = getJsonNumber(json, "precipitation", 0);
                double snow = getJsonNumber(json, "snowfall", 0);
                double wind = getJsonNumber(json, "wind_speed_10m", 0);
                double gusts = getJsonNumber(json, "wind_gusts_10m", wind);
                double visibility = getJsonNumber(json, "visibility", 99999);
                int code = (int) getJsonNumber(json, "weather_code", 0);
                String danger = buildWeatherMessage(temp, rain, precipitation, snow, wind, gusts, visibility, code);
                handler.post(() -> {
                    weatherSummary = danger;
                    if (weatherStatus != null) weatherStatus.setText("🌦️ " + danger);
                    if (speakResult) speak(danger);
                    else maybeWeatherAlert(danger);
                });
            } catch (Exception e) {
                handler.post(() -> {
                    weatherSummary = "Meteorologia indisponível neste momento";
                    if (weatherStatus != null) weatherStatus.setText("🌦️ Meteorologia indisponível");
                    if (speakResult) speak("Não consegui verificar a meteorologia neste momento.");
                });
            }
        }).start();
    }

    double getJsonNumber(String json, String key, double fallback) {
        try {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\\"" + key + "\\\"\\s*:\\s*(-?\\d+(?:\\.\\d+)?)").matcher(json);
            if (m.find()) return Double.parseDouble(m.group(1));
        } catch (Exception ignored) {}
        return fallback;
    }

    String buildWeatherMessage(double temp, double rain, double precipitation, double snow, double wind, double gusts, double visibility, int code) {
        if (snow > 0 || temp <= 1.5) return "Risco de gelo ou neve. Reduza a velocidade e aumente a distância de segurança.";
        if (code >= 95) return "Atenção. Trovoada na zona. Conduza com prudência.";
        if (visibility > 0 && visibility < 1000) return "Nevoeiro denso. Aumente a distância de segurança.";
        if (gusts >= 60 || wind >= 45) return "Vento forte na zona. Segure bem o volante e reduza a velocidade.";
        if (rain >= 4 || precipitation >= 4 || (code >= 61 && code <= 67) || (code >= 80 && code <= 82)) return "Chuva forte na zona. Reduza a velocidade.";
        if (rain > 0 || precipitation > 0 || code == 51 || code == 53 || code == 55) return "Chuva fraca ou piso molhado. Conduza com atenção.";
        if (temp >= 36) return "Temperatura muito alta. Atenção ao cansaço e à pressão dos pneus.";
        return "Meteorologia sem perigo relevante neste momento.";
    }

    void maybeWeatherAlert(String msg) {
        long now = System.currentTimeMillis();
        boolean dangerous = msg.contains("Risco") || msg.contains("Atenção") || msg.contains("forte") || msg.contains("Nevoeiro") || msg.contains("Chuva forte");
        if (dangerous && now - lastWeatherAlert > 30 * 60 * 1000) {
            lastWeatherAlert = now;
            speak(msg);
        }
    }

    void openMaps(String dest) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest)));
            i.setPackage("com.google.android.apps.maps");
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com/?q=" + Uri.encode(dest))));
        }
    }

    void startSensors() {
        Sensor acc = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (acc != null) sensorManager.registerListener(this, acc, SensorManager.SENSOR_DELAY_NORMAL);
    }

    public void onSensorChanged(SensorEvent e) {
        float x = e.values[0], y = e.values[1], z = e.values[2];
        lastMotion = Math.abs((float) Math.sqrt(x * x + y * y + z * z) - 9.81f);
        sensor.setText("Sensor: " + String.format(Locale.US, "%.1f", lastMotion) + " • nível " + levels[level]);
        startTripIfNeeded();
        if (currentSpeed > 10 && lastMotion > thresholds[level] && System.currentTimeMillis() - lastAggressive > 10000) {
            aggressiveAlert();
        }
        checkAutomaticFatigue();
    }

    void checkAutomaticFatigue() {
        if (!tripStarted) return;
        long mins = (System.currentTimeMillis() - tripStartTime) / 60000;
        if (mins >= 120) fatigueAlert(false);
    }

    void aggressiveAlert() {
        lastAggressive = System.currentTimeMillis();
        speak("Atenção. Condução brusca detetada. Conduza com suavidade.");
    }

    void startGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            try {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, this);
            } catch (Exception ignored) {}
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        startGps();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            handler.postDelayed(() -> startListening(), 900);
        } else {
            micWanted = false;
            updateMicButton();
        }
        if (requestCode == 31 && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startFatigueCamera();
        }
    }

    public void onLocationChanged(Location l) {
        if (l.hasSpeed()) currentSpeed = Math.max(0, l.getSpeed() * 3.6);
        lastLat = l.getLatitude();
        lastLon = l.getLongitude();
        speed.setText(Math.round(currentSpeed) + " km/h");
        GeoPoint here = new GeoPoint(lastLat, lastLon);
        updateCarMarker(here);
        if (internalMapEnabled && osmMap != null && osmMap.getVisibility() == View.VISIBLE) {
            if (osmMap.getZoomLevelDouble() < 6) osmMap.getController().setZoom(15.0);
            osmMap.getController().setCenter(here);
        }
        if (currentSpeed > 5) startTripIfNeeded();
        long now = System.currentTimeMillis();
        if (now - lastWeatherCheck > 10 * 60 * 1000) checkWeatherNow(false);
    }

    public void onReadyForSpeech(Bundle p) {
        recognitionStarting = false;
        recognitionActive = true;
        updateMicButton();
    }

    public void onBeginningOfSpeech() {}
    public void onRmsChanged(float rms) {}
    public void onBufferReceived(byte[] b) {}

    public void onEndOfSpeech() {
        recognitionActive = false;
        recognitionStarting = false;
        updateMicButton();
        scheduleRestart(350);
    }

    public void onError(int e) {
        recognitionActive = false;
        recognitionStarting = false;
        destroyRecognizerOnly();
        updateMicButton();

        long delay = 700;
        if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) delay = 250;
        if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) delay = 1000;
        if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            micWanted = false;
            status.setText("Permissão do microfone em falta");
            updateMicButton();
            return;
        }
        scheduleRestart(delay);
    }

    public void onEvent(int t, Bundle b) {}
    public void onAccuracyChanged(Sensor s, int a) {}


    @Override
    public void onConfigurationChanged(@NonNull android.content.res.Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        buildUi();
        if (fatigueCameraActive && cameraProvider != null) {
            bindFatigueCamera();
        }
    }

    protected void onDestroy() {
        micWanted = false;
        if (restartRunnable != null) handler.removeCallbacks(restartRunnable);
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        if (cameraProvider != null) try { cameraProvider.unbindAll(); } catch (Exception ignored) {}
        if (faceDetector != null) faceDetector.close();
        if (cameraExecutor != null) cameraExecutor.shutdown();
        if (emergencyTone != null) emergencyTone.release();
        if (osmMap != null) osmMap.onDetach();
        if (sensorManager != null) sensorManager.unregisterListener(this);
        super.onDestroy();
    }
}
