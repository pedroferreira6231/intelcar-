# Intelcar 2.7 Android Nativo — Modo Carro Horizontal

Base: Intelcar 2.6.1.

Novidades reais desta versão:
- rotação ativada no AndroidManifest;
- modo vertical e modo horizontal;
- ecrã horizontal tipo painel de carro;
- velocidade grande à esquerda;
- destino na segunda linha;
- mapa OpenStreetMap ao centro;
- alertas e botões à direita;
- comando “anular viagem” mantém o comportamento: termina viagem, limpa destino e fecha mapas;
- comando “fechar mapas”;
- mantém microfone corrigido;
- mantém apito forte sem vibração;
- mantém fadiga/distração por câmara;
- mantém meteorologia Open-Meteo;
- novo ícone da aplicação com carro/anjo.

Teste recomendado:
1. Instalar a APK.
2. Abrir o Intelcar.
3. Confirmar microfone.
4. Rodar o telemóvel para horizontal.
5. Testar “Olá Intelcar, leva-me a Fátima”.
6. Testar “anular viagem”.
